import java.util.Scanner;

public class Lab {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a value for n");
        int n = scanner.nextInt();

        System.out.println("The answer to the equation is: ");
        System.out.println(((n + 1) * n + 2) * n + 3);
    }
}
